---
title: Mis Discos
---

<!-- listed from _data/albums.yaml -->
{% include album-list.html list=site.data.albums %}
