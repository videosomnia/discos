---
title: Mis Discos
---

<!-- listed from _data/albums.yaml -->
{% include playlists.html list=site.data.albums  %}
